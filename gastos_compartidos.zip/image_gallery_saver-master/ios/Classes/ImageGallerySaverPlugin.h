#import <Flutter/Flutter.h>

@interface ImageGallerySaverPlugin : NSObject<FlutterPlugin>
@end
