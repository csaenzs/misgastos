package com.arawanastudios.gastos_compartidos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
